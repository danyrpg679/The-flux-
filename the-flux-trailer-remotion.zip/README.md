# THE FLUX — bande-annonce Remotion (60 s, 1920x1080, 60 fps)

## Installation
    npm install
    npx remotion studio          # aperçu interactif (choisis Trailer, Acte1 … Acte5)

## Rendu en plusieurs parties (recommandé)
    npm run render:acte1   # -> out/acte1.mp4
    npm run render:acte2
    npm run render:acte3
    npm run render:acte4
    npm run render:acte5
Assemblage (ffmpeg), dans l'ordre 1 → 5 :
    printf "file 'out/acte1.mp4'\nfile 'out/acte2.mp4'\nfile 'out/acte3.mp4'\nfile 'out/acte4.mp4'\nfile 'out/acte5.mp4'\n" > list.txt
    ffmpeg -f concat -safe 0 -i list.txt -c copy out/the-flux-trailer.mp4
Ou tout d'un coup : `npm run render:all` (plus lourd).
Si ça rame : `--concurrency=1`, ou ajoute `--scale=0.5` pour un test rapide.

## Durées des actes (calées sur la voix off)
| Acte | Contenu | Début | Durée |
|---|---|---|---|
| 1 | L'Univers & le Flux | 0:00 | 18,0 s (1080 i.) |
| 2 | Sylvéra & l'Académie, 7 rangs | 0:18 | 13,6 s (816 i.) |
| 3 | La Menace (musique coupée) | 0:31,6 | 8,15 s (489 i.) |
| 4 | Action & gameplay (R/B/O toutes les 30 i.) | 0:39,75 | 7,73 s (464 i.) |
| 5 | Outro, flash blanc, logo | 0:47,48 | 12,5 s (751 i.) |
Les débuts de paragraphes de la voix off sont dans `src/timeline.ts` (VOICE_START_SEC).
Change-les si tu régénères la voix : tout le montage suit.

## Fichiers
- public/audio/voix-off.mp3 (= _voiceleven2.mp3) et musique.mp3 (= az_recorder_….mp3). Si les deux sont inversés, échange les noms.
- public/audio/sfx_*.wav : effets générés par `python3 make_sfx.py` (lame, impacts, whoosh, riser).
- public/sprites : personnages recomposés depuis les calques du jeu (`build_sprites.py`), armes agrandies.
- src/three/Sprite.tsx : shader GLSL silhouette noire + contour blanc + yeux Bloom.
