import React, {useMemo} from 'react';
import * as CANNON from 'cannon-es';
import {useCurrentFrame} from 'remotion';
import {BW} from './Decor';
import {rnd} from '../timeline';

/**
 * Débris physiques (cannon-es). La simulation est calculée une seule fois
 * (pas fixe 1/60 s) puis relue image par image : rendu 100 % déterministe.
 */
export const Debris: React.FC<{
  origin: [number, number, number];
  start: number; // image de l'explosion
  count?: number;
  seed?: number;
  power?: number;
  size?: number;
  frames?: number;
}> = ({origin, start, count = 22, seed = 1, power = 14, size = 0.7, frames = 240}) => {
  const f = useCurrentFrame();
  const sim = useMemo(() => {
    const world = new CANNON.World({gravity: new CANNON.Vec3(0, -26, 0)});
    const ground = new CANNON.Body({mass: 0, shape: new CANNON.Plane()});
    ground.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
    ground.position.y = 0;
    world.addBody(ground);
    const bodies = Array.from({length: count}, (_, i) => {
      const s = size * (0.5 + rnd(seed + i) * 1.1);
      const b = new CANNON.Body({mass: 1, shape: new CANNON.Box(new CANNON.Vec3(s / 2, s / 2, s / 2))});
      b.position.set(origin[0] + (rnd(seed + i * 3) - 0.5) * 2, origin[1] + rnd(seed + i * 5) * 2, origin[2] + (rnd(seed + i * 7) - 0.5) * 2);
      const a = rnd(seed + i * 11) * Math.PI * 2;
      const p = power * (0.5 + rnd(seed + i * 13));
      b.velocity.set(Math.cos(a) * p, 8 + rnd(seed + i * 17) * power * 0.8, Math.sin(a) * p);
      b.angularVelocity.set((rnd(i) - 0.5) * 18, (rnd(i + 5) - 0.5) * 18, (rnd(i + 9) - 0.5) * 18);
      b.linearDamping = 0.05;
      world.addBody(b);
      (b as any)._s = s;
      return b;
    });
    const track: {p: number[]; q: number[]}[][] = [];
    for (let k = 0; k < frames; k++) {
      world.step(1 / 60);
      track.push(bodies.map((b) => ({p: [b.position.x, b.position.y, b.position.z], q: [b.quaternion.x, b.quaternion.y, b.quaternion.z, b.quaternion.w]})));
    }
    return {sizes: bodies.map((b) => (b as any)._s as number), track};
  }, [origin[0], origin[1], origin[2], count, seed, power, size, frames]);

  const k = f - start;
  if (k < 0) return null;
  const frameData = sim.track[Math.min(k, frames - 1)];
  return (
    <group>
      {frameData.map((d, i) => (
        <group key={i} position={d.p as any} quaternion={d.q as any}>
          <BW outline={0.05}>
            <boxGeometry args={[sim.sizes[i], sim.sizes[i], sim.sizes[i]]} />
          </BW>
        </group>
      ))}
    </group>
  );
};
