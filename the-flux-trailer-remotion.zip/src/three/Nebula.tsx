import React, {useLayoutEffect, useRef} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {useCurrentFrame} from 'remotion';
import Nebula, {
  Alpha, Body, BoxZone, Color, Emitter, Force, Life, Mass, Position, RadialVelocity,
  RandomDrift, Radius, Rate, Scale, Span, SpriteRenderer, Vector3D,
  // @ts-ignore
} from 'three-nebula';

/**
 * Particules three-nebula, rendues de façon DÉTERMINISTE pour Remotion :
 *  - Math.random est remplacé par un PRNG à graine pendant la simulation,
 *  - à chaque image on avance d'un pas fixe de 1/60 s,
 *  - si Remotion saute à une image arbitraire (rendu parallèle), on re-simule depuis 0.
 */
export type Preset = 'embers' | 'wind' | 'leaves' | 'energy' | 'sparks';

const mulberry = (a: number) => () => {
  a |= 0; a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

let _tex: THREE.Texture | null = null;
const dotTexture = () => {
  if (_tex) return _tex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d')!;
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)');
  gr.addColorStop(0.35, 'rgba(255,255,255,0.8)');
  gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  _tex = new THREE.CanvasTexture(c);
  return _tex;
};

const build = (preset: Preset, area: [number, number, number], center: [number, number, number]) => {
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: dotTexture(),
      transparent: true,
      depthWrite: false,
      blending: preset === 'embers' || preset === 'energy' || preset === 'sparks' ? THREE.AdditiveBlending : THREE.NormalBlending,
      color: 0xffffff,
    }),
  );
  const cfg = {
    embers: {rate: [6, 0.04], life: [3, 6], r: [0.18, 0.5], vel: [2, 5], dir: [0, 1, 0], c: ['#ffb000', '#ff2200'], force: [0.4, 1.4, 0.2], drift: 2.5},
    wind: {rate: [5, 0.03], life: [0.8, 1.6], r: [0.1, 0.25], vel: [28, 46], dir: [0.1, 0.03, 1], c: ['#ffffff', '#ffffff'], force: [0, 0, 0], drift: 0.6},
    leaves: {rate: [3, 0.06], life: [3, 5], r: [0.35, 0.7], vel: [5, 11], dir: [0.4, -0.25, 1], c: ['#ffffff', '#cfe3ff'], force: [0, -0.4, 1.5], drift: 4},
    energy: {rate: [8, 0.03], life: [1, 2.2], r: [0.12, 0.4], vel: [4, 9], dir: [0, 1, 0], c: ['#ffffff', '#66aaff'], force: [0, 2, 0], drift: 3},
    sparks: {rate: [14, 0.02], life: [0.5, 1.1], r: [0.1, 0.3], vel: [14, 26], dir: [0, 1, 0], c: ['#ffffff', '#ffcc66'], force: [0, -9, 0], drift: 0.5},
  }[preset] as any;
  const e = new Emitter();
  e.setRate(new Rate(new Span(cfg.rate[0], cfg.rate[0] + 4), new Span(cfg.rate[1], cfg.rate[1] + 0.03)))
    .addInitializers([
      new Mass(1),
      new Radius(cfg.r[0], cfg.r[1]),
      new Life(cfg.life[0], cfg.life[1]),
      new Body(sprite),
      new Position(new BoxZone(area[0], area[1], area[2])),
      new RadialVelocity(new Span(cfg.vel[0], cfg.vel[1]), new Vector3D(cfg.dir[0], cfg.dir[1], cfg.dir[2]), 28),
    ])
    .addBehaviours([
      new Alpha(1, 0),
      new Scale(1, 0.25),
      new Color(cfg.c[0], cfg.c[1]),
      new Force(cfg.force[0] / 100, cfg.force[1] / 100, cfg.force[2] / 100), // three-nebula normalise x100
      new RandomDrift(cfg.drift / 100, cfg.drift / 100, cfg.drift / 100, 0.05),
    ]);
  e.position.set(center[0], center[1], center[2]);
  e.emit();
  return e;
};

export const Particles: React.FC<{
  preset: Preset;
  seed?: number;
  area?: [number, number, number];
  center?: [number, number, number]; // suit éventuellement la caméra via une fonction ?
  follow?: (f: number) => [number, number, number];
}> = ({preset, seed = 1, area = [60, 20, 60], center = [0, 0, 0], follow}) => {
  const {scene} = useThree();
  const frame = useCurrentFrame();
  const st = useRef<{sys: any; last: number} | null>(null);

  const create = () => {
    const sys = new Nebula();
    const group = new THREE.Group();
    scene.add(group);
    const em = build(preset, area, follow ? follow(0) : center);
    sys.addEmitter(em).addRenderer(new SpriteRenderer(group, THREE));
    const destroy = () => { try { sys.destroy(); } catch {} scene.remove(group); group.clear(); };
    return {sys, em, group, destroy, last: -1} as any;
  };

  useLayoutEffect(() => {
    return () => {
      (st.current as any)?.destroy?.();
      st.current = null;
    };
  }, [preset, seed]);

  useLayoutEffect(() => {
    const realRandom = Math.random;
    const prng = mulberry(seed * 9973);
    const step = () => {
      const s = st.current as any;
      if (follow) s.em.position.set(...follow(s.last + 1));
      Math.random = prng;
      try { s.sys.update(1 / 60); } finally { Math.random = realRandom; }
      s.last += 1;
    };
    if (!st.current || frame < st.current.last || frame > st.current.last + 1) {
      (st.current as any)?.destroy?.();
      st.current = create();
      // pré-chauffe : simule depuis 0 jusqu'à l'image courante (limité à 900 pas)
      const from = Math.max(0, frame - 900);
      st.current!.last = from - 1;
      while (st.current!.last < frame) step();
    } else if (frame === st.current.last + 1) {
      step();
    }
  });
  return null;
};
