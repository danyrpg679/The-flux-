import React, {useMemo} from 'react';
import {Edges, Outlines} from '@react-three/drei';
import {rnd} from '../timeline';

type V3 = [number, number, number];

/** Mesh noir pur (#000) + contour blanc (#FFF) : Outlines (coque inversée) + Edges (arêtes). */
export const BW: React.FC<{
  children: React.ReactNode;
  position?: V3;
  rotation?: V3;
  scale?: V3 | number;
  outline?: number;
}> = ({children, position, rotation, scale, outline = 0.07}) => (
  <mesh position={position} rotation={rotation} scale={scale as any}>
    {children}
    <meshBasicMaterial color="#000000" />
    <Outlines thickness={outline} color="#ffffff" angle={0} />
    <Edges threshold={20} color="#ffffff" />
  </mesh>
);

const Ground: React.FC<{size?: number; y?: number}> = ({size = 300, y = 0}) => (
  <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, y, 0]}>
    <planeGeometry args={[size, size, 30, 30]} />
    <meshBasicMaterial color="#000000" />
    <Edges color="#ffffff" threshold={1} />
  </mesh>
);

/** Toits du village de Sylvéra : maisons à toit en pente le long d'un axe. */
export const Rooftops: React.FC<{seed?: number; count?: number; length?: number; width?: number}> = ({
  seed = 1,
  count = 46,
  length = 150,
  width = 26,
}) => {
  const houses = useMemo(
    () =>
      Array.from({length: count}, (_, i) => {
        const r = (k: number) => rnd(seed * 100 + i * 7 + k);
        const w = 3 + r(1) * 4, d = 3 + r(2) * 4, h = 2 + r(3) * 3;
        return {
          x: ((r(4) - 0.5) * width) + (r(4) < 0.5 ? -7 : 7),
          z: -r(5) * length + 15,
          y: r(6) * 2.2,
          w, d, h,
          roof: 1 + r(7) * 1.4,
          chim: r(8) > 0.55,
          ry: (r(9) - 0.5) * 0.5,
        };
      }),
    [seed, count, length, width],
  );
  return (
    <group>
      {houses.map((hs, i) => (
        <group key={i} position={[hs.x, hs.y, hs.z]} rotation={[0, hs.ry, 0]}>
          <BW position={[0, hs.h / 2, 0]}>
            <boxGeometry args={[hs.w, hs.h, hs.d]} />
          </BW>
          {/* toit : prisme triangulaire */}
          <BW position={[0, hs.h + hs.roof / 2, 0]} rotation={[0, 0, Math.PI / 2]} scale={[hs.roof / (hs.w * 0.5), 1, 1]}>
            <cylinderGeometry args={[hs.w * 0.5, hs.w * 0.5, hs.d + 0.8, 3]} />
          </BW>
          {hs.chim ? (
            <BW position={[hs.w * 0.25, hs.h + hs.roof + 0.5, 0]}>
              <boxGeometry args={[0.7, 1.6, 0.7]} />
            </BW>
          ) : null}
        </group>
      ))}
      <Ground size={400} y={-0.5} />
    </group>
  );
};

/** Champ de bataille : lances brisées, rochers, bannières, arches en ruine. */
export const Battlefield: React.FC<{seed?: number}> = ({seed = 3}) => {
  const items = useMemo(
    () =>
      Array.from({length: 90}, (_, i) => {
        const r = (k: number) => rnd(seed * 50 + i * 11 + k);
        return {
          kind: Math.floor(r(1) * 4),
          x: (r(2) - 0.5) * 120,
          z: 30 - r(3) * 140,
          s: 0.6 + r(4) * 1.8,
          tilt: (r(5) - 0.5) * 0.7,
          ry: r(6) * 6.28,
        };
      }),
    [seed],
  );
  return (
    <group>
      <Ground size={500} y={0} />
      {items.map((it, i) => {
        const p: V3 = [it.x, 0, it.z];
        if (it.kind === 0)
          return (
            <BW key={i} position={[p[0], 3 * it.s, p[2]]} rotation={[it.tilt, it.ry, it.tilt]}>
              <coneGeometry args={[0.18 * it.s, 6 * it.s, 5]} />
            </BW>
          );
        if (it.kind === 1)
          return (
            <BW key={i} position={[p[0], 0.8 * it.s, p[2]]} rotation={[it.tilt, it.ry, 0]}>
              <dodecahedronGeometry args={[1.2 * it.s, 0]} />
            </BW>
          );
        if (it.kind === 2)
          return (
            <group key={i} position={p} rotation={[0, it.ry, 0]}>
              <BW position={[0, 3.5 * it.s, 0]}>
                <cylinderGeometry args={[0.07, 0.07, 7 * it.s, 5]} />
              </BW>
              <BW position={[0.9 * it.s, 5.6 * it.s, 0]} rotation={[0, 0, -0.15]}>
                <boxGeometry args={[1.8 * it.s, 1.1 * it.s, 0.04]} />
              </BW>
            </group>
          );
        return (
          <group key={i} position={p} rotation={[0, it.ry, 0]}>
            <BW position={[-1.6 * it.s, 2.2 * it.s, 0]}>
              <boxGeometry args={[0.8 * it.s, 4.4 * it.s, 0.8 * it.s]} />
            </BW>
            <BW position={[1.6 * it.s, 1.4 * it.s, 0]} rotation={[0, 0, 0.2]}>
              <boxGeometry args={[0.8 * it.s, 2.8 * it.s, 0.8 * it.s]} />
            </BW>
          </group>
        );
      })}
      {/* montagnes lointaines */}
      {Array.from({length: 9}, (_, i) => (
        <BW key={'m' + i} position={[-80 + i * 20, 12, -170 - rnd(i) * 20]}>
          <coneGeometry args={[14 + rnd(i + 4) * 8, 24 + rnd(i + 9) * 14, 4]} />
        </BW>
      ))}
    </group>
  );
};

/** Forêt stylisée : troncs + cônes empilés. */
export const Forest: React.FC<{seed?: number; count?: number}> = ({seed = 5, count = 60}) => {
  const trees = useMemo(
    () =>
      Array.from({length: count}, (_, i) => ({
        x: (rnd(seed + i * 3) - 0.5) * 70,
        z: 20 - rnd(seed + i * 5 + 1) * 90,
        s: 0.8 + rnd(seed + i * 7 + 2) * 1.1,
      })),
    [seed, count],
  );
  return (
    <group>
      <Ground size={300} />
      {trees.map((t, i) => (
        <group key={i} position={[t.x, 0, t.z]} scale={t.s}>
          <BW position={[0, 2, 0]}>
            <cylinderGeometry args={[0.35, 0.5, 4, 6]} />
          </BW>
          <BW position={[0, 5, 0]}>
            <coneGeometry args={[2.4, 4.2, 7]} />
          </BW>
          <BW position={[0, 7.4, 0]}>
            <coneGeometry args={[1.8, 3.4, 7]} />
          </BW>
        </group>
      ))}
    </group>
  );
};

/** Arène : disque central + anneau de piliers + gradins. */
export const Arena: React.FC<{hidePillars?: number[]}> = ({hidePillars = []}) => (
  <group>
    <BW position={[0, -0.4, 0]} outline={0.1}>
      <cylinderGeometry args={[17, 17, 0.8, 40]} />
    </BW>
    <BW position={[0, -0.35, 0]}>
      <cylinderGeometry args={[11, 11, 0.9, 40]} />
    </BW>
    {Array.from({length: 14}, (_, i) => {
      if (hidePillars.includes(i)) return null;
      const a = (i / 14) * Math.PI * 2;
      const h = 6 + rnd(i * 3) * 4;
      return (
        <BW key={i} position={[Math.cos(a) * 19, h / 2, Math.sin(a) * 19]}>
          <cylinderGeometry args={[0.9, 1.1, h, 6]} />
        </BW>
      );
    })}
    {Array.from({length: 22}, (_, i) => {
      const a = (i / 22) * Math.PI * 2;
      return (
        <BW key={'s' + i} position={[Math.cos(a) * 27, 1.5 + (i % 3), Math.sin(a) * 27]} rotation={[0, -a, 0]}>
          <boxGeometry args={[2.2, 3 + (i % 3) * 2, 7]} />
        </BW>
      );
    })}
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.8, 0]}>
      <circleGeometry args={[120, 32]} />
      <meshBasicMaterial color="#000000" />
    </mesh>
  </group>
);

/** Toits « tremplins » sur lesquels courent les personnages (centre de la rue). */
export const PATH_STEP = 14;
export const pathTop = (i: number) => 6.2 + 2.2 * Math.sin(i * 1.7) + 1.2 + (i % 3) * 0.4;
export const PathRoofs: React.FC<{count?: number; z0?: number}> = ({count = 14, z0 = 10}) => (
  <group>
    {Array.from({length: count}, (_, i) => {
      const top = pathTop(i) - 1.2;
      return (
        <group key={i} position={[0, 0, z0 - i * PATH_STEP]}>
          <BW position={[0, top / 2, 0]}>
            <boxGeometry args={[7, top, 9]} />
          </BW>
          <BW position={[0, top + 0.6, 0]} rotation={[0, 0, Math.PI / 2]} scale={[0.35, 1, 1]}>
            <cylinderGeometry args={[3.8, 3.8, 9.6, 3]} />
          </BW>
        </group>
      );
    })}
  </group>
);
