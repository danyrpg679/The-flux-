import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {useTexture} from '@react-three/drei';
import {staticFile, useCurrentFrame} from 'remotion';

/**
 * Sprite 2D -> silhouette noire pur (#000) + contour blanc net (#FFF), calculés
 * en GLSL à partir du canal alpha du PNG (n'importe quel sprite transparent marche).
 * Plan 3D subdivisé : inclinaison (lean) + vent (cheveux/cape) dans le vertex shader.
 * Yeux : 2e plan, blanc surexposé (> 1.0) => capté par le Bloom.
 */
export type Pose = {
  pos: [number, number, number];
  scale?: number;
  sx?: number; // squash & stretch horizontal
  sy?: number; // squash & stretch vertical
  rotZ?: number;
  lean?: number; // cisaillement (unités monde en haut du sprite)
  wind?: number; // amplitude du vent
  flip?: boolean;
  opacity?: number;
};

const VERT = /* glsl */ `
uniform float uLean; uniform float uWind; uniform float uTime; uniform float uPad;
varying vec2 vUv;
void main(){
  vUv = (uv - 0.5) * uPad + 0.5;
  vec3 p = position;
  float h = clamp(uv.y, 0.0, 1.0);
  p.x += uLean * h;
  float side = abs(uv.x - 0.5) * 2.0;
  p.x += sin(uTime * 7.0 + h * 6.0 + uv.x * 3.0) * uWind * (0.15 + 0.85 * h) * (0.3 + side);
  p.y += sin(uTime * 5.0 + uv.x * 8.0) * uWind * 0.25 * h;
  gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
}`;

const FRAG = /* glsl */ `
uniform sampler2D uMap; uniform vec2 uTexel; uniform float uOutline;
uniform vec3 uFill; uniform vec3 uLine; uniform float uOpacity; uniform float uMode; uniform float uBoost;
varying vec2 vUv;
float A(vec2 uv){ if(uv.x<0.0||uv.x>1.0||uv.y<0.0||uv.y>1.0) return 0.0; return texture2D(uMap, uv).a; }
void main(){
  float a = A(vUv);
  if(uMode > 0.5){
    if(a < 0.25) discard;
    gl_FragColor = vec4(vec3(uBoost), a * uOpacity);
    return;
  }
  float m = 0.0;
  for(int i=0;i<24;i++){
    float t = float(i) * 0.2617994;
    vec2 d = vec2(cos(t), sin(t)) * uTexel * uOutline;
    m = max(m, A(vUv + d));
    m = max(m, A(vUv + d * 0.55));
  }
  float fillA = smoothstep(0.35, 0.6, a);
  float lineA = smoothstep(0.35, 0.6, m);
  if(lineA < 0.01) discard;
  gl_FragColor = vec4(mix(uLine, uFill, fillA), max(fillA, lineA) * uOpacity);
}`;

type Props = {
  src: string; // ex: 'zephyra' (public/sprites/zephyra.png)
  eyes?: boolean; // charge public/sprites/<src>_eyes.png
  height: number; // hauteur monde
  pose: (frame: number) => Pose;
  trail?: number; // nb de fantômes (motion trail)
  trailStep?: number;
  outline?: number; // épaisseur du contour en pixels de texture
  eyeBoost?: (frame: number) => number; // intensité des yeux (0 = éteints)
  ghostColor?: string;
  facing?: boolean; // billboard (défaut true)
};

const PAD = 1.14;

const SpriteLayer: React.FC<{
  tex: THREE.Texture;
  geo: THREE.BufferGeometry;
  pose: Pose;
  frame: number;
  mode: 0 | 1;
  boost?: number;
  fill?: string;
  line?: string;
  outline: number;
  z?: number;
  opacity?: number;
  facing: boolean;
}> = ({tex, geo, pose, frame, mode, boost = 6, fill = '#000000', line = '#ffffff', outline, z = 0, opacity = 1, facing}) => {
  const {camera} = useThree();
  const g = useRef<THREE.Group>(null);
  const mat = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: VERT,
        fragmentShader: FRAG,
        transparent: true,
        depthWrite: mode === 0,
        side: THREE.DoubleSide,
        uniforms: {
          uMap: {value: tex},
          uTexel: {value: new THREE.Vector2(1 / tex.image.width, 1 / tex.image.height)},
          uOutline: {value: outline},
          uFill: {value: new THREE.Color(fill)},
          uLine: {value: new THREE.Color(line)},
          uOpacity: {value: 1},
          uMode: {value: mode},
          uBoost: {value: boost},
          uLean: {value: 0},
          uWind: {value: 0},
          uTime: {value: 0},
          uPad: {value: PAD},
        },
      }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [tex, mode],
  );
  mat.uniforms.uLean.value = pose.lean ?? 0;
  mat.uniforms.uWind.value = pose.wind ?? 0;
  mat.uniforms.uTime.value = frame / 60;
  mat.uniforms.uOpacity.value = (pose.opacity ?? 1) * opacity;
  mat.uniforms.uBoost.value = boost;
  mat.uniforms.uOutline.value = outline;
  mat.uniforms.uFill.value.set(fill);
  mat.uniforms.uLine.value.set(line);

  useLayoutEffect(() => {
    if (facing && g.current) g.current.quaternion.copy(camera.quaternion);
  });

  const s = pose.scale ?? 1;
  return (
    <group ref={g} position={[pose.pos[0], pose.pos[1], pose.pos[2]]}>
      <mesh
        geometry={geo}
        material={mat}
        position={[0, 0, z]}
        rotation={[0, 0, pose.rotZ ?? 0]}
        scale={[(pose.flip ? -1 : 1) * s * (pose.sx ?? 1), s * (pose.sy ?? 1), 1]}
        renderOrder={mode === 1 ? 5 : 2}
      />
    </group>
  );
};

export const Sprite: React.FC<Props> = ({
  src,
  eyes = true,
  height,
  pose,
  trail = 0,
  trailStep = 3,
  outline = 7,
  eyeBoost = () => 6,
  ghostColor = '#ffffff',
  facing = true,
}) => {
  const frame = useCurrentFrame();
  const paths = eyes ? [staticFile(`sprites/${src}.png`), staticFile(`sprites/${src}_eyes.png`)] : [staticFile(`sprites/${src}.png`)];
  const texs = useTexture(paths) as THREE.Texture[];
  texs.forEach((t) => {
    t.minFilter = THREE.LinearFilter;
    t.magFilter = THREE.LinearFilter;
    t.generateMipmaps = false;
  });
  const [body, eye] = texs;
  const geo = useMemo(() => {
    const aspect = body.image.width / body.image.height;
    const gg = new THREE.PlaneGeometry(height * aspect * PAD, height * PAD, 14, 22);
    gg.translate(0, height / 2, 0); // pivot = pieds
    return gg;
  }, [body, height]);

  const p = pose(frame);
  const ghosts = [];
  for (let k = trail; k >= 1; k--) {
    const gp = pose(frame - k * trailStep);
    ghosts.push(
      <SpriteLayer
        key={k}
        tex={body}
        geo={geo}
        pose={gp}
        frame={frame}
        mode={0}
        fill={ghostColor}
        line={ghostColor}
        outline={outline}
        z={-0.02 * k}
        opacity={(1 - k / (trail + 1)) * 0.45}
        facing={facing}
      />,
    );
  }
  const boost = eyeBoost(frame);
  return (
    <>
      {ghosts}
      <SpriteLayer tex={body} geo={geo} pose={p} frame={frame} mode={0} outline={outline} facing={facing} />
      {eye && boost > 0 ? (
        <SpriteLayer tex={eye} geo={geo} pose={p} frame={frame} mode={1} boost={boost} outline={outline} z={0.03} facing={facing} />
      ) : null}
    </>
  );
};
