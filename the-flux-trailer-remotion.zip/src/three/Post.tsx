import React from 'react';
import * as THREE from 'three';
import {Bloom, ChromaticAberration, EffectComposer} from '@react-three/postprocessing';

/**
 * Bloom : seuil > 1.0 => seuls les yeux (≈6.0) et éclats de Flux surexposés brillent,
 * les contours blancs (=1.0) et les fonds restent nets.
 * ChromaticAberration : pilotée par les impacts.
 */
export const Post: React.FC<{bloom?: number; aberration?: number}> = ({bloom = 1.8, aberration = 0}) => (
  <EffectComposer multisampling={0}>
    <Bloom intensity={bloom} luminanceThreshold={1.02} luminanceSmoothing={0.15} mipmapBlur radius={0.85} />
    <ChromaticAberration offset={new THREE.Vector2(aberration, aberration * 0.6)} radialModulation={false} modulationOffset={0} />
  </EffectComposer>
);
