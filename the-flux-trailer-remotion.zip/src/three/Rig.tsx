import {useLayoutEffect} from 'react';
import {useThree} from '@react-three/fiber';
import {useCurrentFrame} from 'remotion';
import {rnd} from '../timeline';

export type Cam = {pos: [number, number, number]; look: [number, number, number]; fov?: number; roll?: number};

/** Caméra pilotée par une fonction pure de l'image + tremblement (shake) réactif. */
export const Rig: React.FC<{cam: (f: number) => Cam; shake?: number}> = ({cam, shake = 0}) => {
  const {camera} = useThree();
  const f = useCurrentFrame();
  useLayoutEffect(() => {
    const c = cam(f);
    const sx = (rnd(f * 1.7) - 0.5) * shake;
    const sy = (rnd(f * 2.3 + 9) - 0.5) * shake;
    camera.position.set(c.pos[0] + sx, c.pos[1] + sy, c.pos[2]);
    camera.lookAt(c.look[0], c.look[1], c.look[2]);
    if (c.roll) camera.rotateZ(c.roll);
    const pc = camera as THREE.PerspectiveCamera;
    pc.fov = c.fov ?? 50;
    pc.updateProjectionMatrix();
    camera.updateMatrixWorld();
  });
  return null;
};
import type * as THREE from 'three';
