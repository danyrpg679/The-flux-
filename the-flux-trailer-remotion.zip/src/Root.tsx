import React from 'react';
import {Composition} from 'remotion';
import {ACT_COMPONENTS, Trailer} from './Trailer';
import {ACT_DUR, ACT_NAMES, FPS, HEIGHT, TOTAL, WIDTH} from './timeline';

export const Root: React.FC = () => (
  <>
    {/* Vidéo entière (3600 images = 60 s) */}
    <Composition id="Trailer" component={Trailer} durationInFrames={TOTAL} fps={FPS} width={WIDTH} height={HEIGHT} />
    {/* Chaque acte seul : à rendre séparément puis à assembler (ordre 1 → 5) */}
    {ACT_COMPONENTS.map((A, i) => (
      <Composition key={ACT_NAMES[i]} id={ACT_NAMES[i]} component={A} durationInFrames={ACT_DUR[i]} fps={FPS} width={WIDTH} height={HEIGHT} />
    ))}
  </>
);
