declare module 'three-nebula';
