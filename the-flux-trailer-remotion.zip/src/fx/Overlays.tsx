import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {useAudioData, visualizeAudio} from '@remotion/media-utils';
import {ACT_START, C, FPS, clamp, easeOut, rnd} from '../timeline';

/** Basses de la musique (0..1) à l'image absolue de l'acte. `gate` coupe le signal (ex. musique coupée). */
export const useBass = (act: number, gate: (f: number) => number = () => 1): number => {
  const frame = useCurrentFrame();
  const data = useAudioData(staticFile('audio/musique.mp3'));
  if (!data) return 0;
  const abs = ACT_START[act] + frame;
  const bins = visualizeAudio({fps: FPS, frame: abs, audioData: data, numberOfSamples: 16});
  const b = (bins[0] + bins[1] + bins[2]) / 3;
  return clamp(b * 3.2) * gate(frame);
};

/** Tremblement de l'écran entier, dépend de l'amplitude (impacts + basses). */
export const Shake: React.FC<{amp: number; children: React.ReactNode}> = ({amp, children}) => {
  const f = useCurrentFrame();
  const dx = (rnd(f * 3.1) - 0.5) * 2 * amp;
  const dy = (rnd(f * 5.7 + 4) - 0.5) * 2 * amp;
  const r = (rnd(f * 1.3 + 8) - 0.5) * amp * 0.03;
  return (
    <AbsoluteFill style={{transform: `translate(${dx}px, ${dy}px) rotate(${r}deg) scale(1.03)`}}>{children}</AbsoluteFill>
  );
};

/** Lignes de vitesse manga (rayonnantes ou parallèles), animées « on twos ». */
export const SpeedLines: React.FC<{
  opacity?: number;
  color?: string;
  mode?: 'radial' | 'horizontal';
  density?: number;
  angle?: number;
}> = ({opacity = 1, color = '#fff', mode = 'radial', density = 70, angle = 0}) => {
  const f = Math.floor(useCurrentFrame() / 4);
  if (opacity <= 0.01) return null;
  const lines = Array.from({length: density}, (_, i) => {
    const r = (k: number) => rnd(f * 91 + i * 13 + k);
    if (mode === 'radial') {
      const a = r(1) * Math.PI * 2;
      const r0 = 330 + r(2) * 260, r1 = r0 + 260 + r(3) * 700;
      const w = 0.006 + r(4) * 0.02;
      const cx = 960, cy = 540;
      const p = (rr: number, aa: number) => `${cx + Math.cos(aa) * rr},${cy + Math.sin(aa) * rr * 0.62}`;
      return <polygon key={i} points={`${p(r0, a - w)} ${p(r1, a)} ${p(r0, a + w)}`} fill={color} />;
    }
    const y = r(1) * 1080, len = 300 + r(2) * 1200, x = r(3) * 2200 - 300, th = 1 + r(4) * 7;
    return <rect key={i} x={x} y={y} width={len} height={th} fill={color} />;
  });
  return (
    <AbsoluteFill style={{opacity}}>
      <svg width={1920} height={1080} style={{transform: `rotate(${angle}deg)`}}>{lines}</svg>
    </AbsoluteFill>
  );
};

/** Flash plein écran (blanc par défaut) avec décroissance. */
export const Flash: React.FC<{at: number; dur?: number; color?: string}> = ({at, dur = 8, color = '#fff'}) => {
  const f = useCurrentFrame();
  const o = f < at ? 0 : interpolate(f, [at, at + dur], [1, 0], {extrapolateRight: 'clamp'});
  return o > 0 ? <AbsoluteFill style={{background: color, opacity: o}} /> : null;
};

/** Slash blanc diagonal qui traverse l'écran. */
export const Slash: React.FC<{at: number; dur?: number; angle?: number; thick?: number}> = ({at, dur = 10, angle = -18, thick = 26}) => {
  const f = useCurrentFrame();
  if (f < at || f > at + dur + 14) return null;
  const t = clamp((f - at) / dur);
  const fade = clamp(1 - (f - at - dur) / 14);
  const len = 2800 * easeOut(t);
  return (
    <AbsoluteFill style={{opacity: fade}}>
      <div
        style={{
          position: 'absolute', left: 960 - 1400, top: 540 - thick / 2, width: len, height: thick,
          background: '#fff', transform: `rotate(${angle}deg)`, transformOrigin: '0 50%',
          clipPath: 'polygon(0 50%, 6% 0, 100% 35%, 100% 65%, 6% 100%)', boxShadow: '0 0 60px #fff',
        }}
      />
    </AbsoluteFill>
  );
};

/** Mot martelé (typo cinétique) : entre en slam, tremble, sort en cut. */
export const Word: React.FC<{
  text: string; from: number; dur: number; size?: number; color?: string; stroke?: string;
  x?: number; y?: number; rot?: number; sub?: string;
}> = ({text, from, dur, size = 360, color = '#fff', stroke = '#000', x = 960, y = 540, rot = -4, sub}) => {
  const f = useCurrentFrame();
  if (f < from || f >= from + dur) return null;
  const t = f - from;
  const s = 1 + 1.3 * Math.pow(1 - clamp(t / 7), 2);
  const jx = (rnd(f * 2.1) - 0.5) * 8, jy = (rnd(f * 3.7) - 0.5) * 8;
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: x + jx, top: y + jy, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${s})`, textAlign: 'center'}}>
        <div style={{fontFamily: 'Impact, "Arial Black", sans-serif', fontSize: size, lineHeight: 0.95, letterSpacing: 4, color, WebkitTextStroke: `10px ${stroke}`, paintOrder: 'stroke fill' as any, textShadow: `14px 14px 0 ${stroke}`}}>
          {text}
        </div>
        {sub ? <div style={{fontFamily: 'Impact, sans-serif', fontSize: size * 0.2, color, letterSpacing: 14, marginTop: 8, textShadow: `4px 4px 0 ${stroke}`}}>{sub}</div> : null}
      </div>
    </AbsoluteFill>
  );
};

/** Bandes cinéma. */
export const Letterbox: React.FC<{h?: number}> = ({h = 70}) => (
  <AbsoluteFill style={{pointerEvents: 'none'}}>
    <div style={{position: 'absolute', top: 0, left: 0, right: 0, height: h, background: '#000'}} />
    <div style={{position: 'absolute', bottom: 0, left: 0, right: 0, height: h, background: '#000'}} />
  </AbsoluteFill>
);

/** Effet sonore à une image donnée de l'acte. */
export const Sfx: React.FC<{name: 'slash' | 'hit' | 'boom' | 'whoosh' | 'riser'; at: number; volume?: number}> = ({name, at, volume = 0.9}) => (
  <Sequence from={at} layout="none">
    <Audio src={staticFile(`audio/sfx_${name}.wav`)} volume={volume} />
  </Sequence>
);

/** Interface de combat au tour par tour (rappelle le menu du jeu). */
export const BattleUI: React.FC<{from: number; hp?: [number, number]; turn?: number; cursor?: number}> = ({from, hp = [0.8, 0.55], turn = 1, cursor = 0}) => {
  const f = useCurrentFrame() - from;
  if (f < 0) return null;
  const slide = easeOut(f / 10);
  const items = ['ATTAQUE', 'ART', 'FLUX', 'FUIR'];
  const bar = (label: string, v: number, col: string) => (
    <div style={{marginBottom: 10}}>
      <div style={{color: '#fff', fontFamily: 'Impact', fontSize: 28, letterSpacing: 3}}>{label}</div>
      <div style={{width: 520, height: 22, background: '#000', border: '4px solid #fff', transform: 'skewX(-18deg)'}}>
        <div style={{width: `${v * 100}%`, height: '100%', background: col}} />
      </div>
    </div>
  );
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 70 - (1 - slide) * 400, bottom: 110}}>
        {bar('ZÉPHYRA  S', hp[0], '#fff')}
        {bar('ADEPTE  F', hp[1], '#E60012')}
      </div>
      <div style={{position: 'absolute', right: 70 + (1 - slide) * 400, bottom: 110, display: 'flex', flexDirection: 'column', gap: 8}}>
        {items.map((it, i) => (
          <div key={it} style={{fontFamily: 'Impact', fontSize: 44, letterSpacing: 4, padding: '2px 26px', background: i === cursor ? '#fff' : '#000', color: i === cursor ? '#000' : '#fff', border: '4px solid #fff', transform: 'skewX(-14deg)', width: 280}}>
            {i === cursor ? '▶ ' : ''}{it}
          </div>
        ))}
      </div>
      <div style={{position: 'absolute', top: 100, left: 70, fontFamily: 'Impact', fontSize: 56, color: '#fff', letterSpacing: 6, WebkitTextStroke: '4px #000', paintOrder: 'stroke fill' as any}}>
        TOUR {turn}
      </div>
    </AbsoluteFill>
  );
};
