import React from 'react';
import {AbsoluteFill, Audio, staticFile} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {ACT_START, HEIGHT, VOICE_START_SEC, WIDTH, sec} from '../timeline';

/** Canvas 3D 1080p avec fond de couleur unie. */
export const Stage: React.FC<{bg: string; children: React.ReactNode}> = ({bg, children}) => (
  <ThreeCanvas
    width={WIDTH}
    height={HEIGHT}
    dpr={1}
    camera={{fov: 50, near: 0.1, far: 600, position: [0, 5, 20]}}
    gl={{antialias: true, alpha: false, powerPreference: 'high-performance'}}
    style={{position: 'absolute', inset: 0}}
  >
    <color attach="background" args={[bg]} />
    {children}
  </ThreeCanvas>
);

/** Voix off + musique de l'acte, calées sur la timeline globale. */
export const ActAudio: React.FC<{act: number; music?: (f: number) => number}> = ({act, music}) => (
  <AbsoluteFill>
    <Audio src={staticFile('audio/musique.mp3')} startFrom={ACT_START[act]} volume={music ?? (() => 0.6)} />
    <Audio src={staticFile('audio/voix-off.mp3')} startFrom={sec(VOICE_START_SEC[act])} volume={1} />
  </AbsoluteFill>
);
