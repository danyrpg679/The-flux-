// ─────────────────────────────────────────────────────────────
//  THE FLUX — timeline. 60 fps, 1920x1080, 3600 images = 60 s
// ─────────────────────────────────────────────────────────────
export const FPS = 60;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL = 3600;

export const C = {
  black: '#000000',
  red: '#E60012',
  blue: '#0066FF',
  orange: '#FF6600',
  white: '#FFFFFF',
};

export const sec = (s: number) => Math.round(s * FPS);

/**
 * Seconde (dans voix-off.mp3) où commence chaque paragraphe de la voix off.
 * Détectées automatiquement via les silences de la piste. Si tu changes la
 * voix off, ajuste ces 5 valeurs : tout le montage suit.
 *   Acte 1 "Dans un monde façonné…"   Acte 2 "Aujourd'hui, la paix…"
 *   Acte 3 "Mais dans l'ombre…"        Acte 4 "Fais tes choix…"
 *   Acte 5 "Ta voie reste à écrire…"
 */
export const VOICE_START_SEC = [0, 18.0, 31.6, 39.75, 47.48];

export const ACT_START = VOICE_START_SEC.map(sec); // [0,1080,1896,2385,2849]
export const ACT_END = [...ACT_START.slice(1), TOTAL];
export const ACT_DUR = ACT_START.map((s, i) => ACT_END[i] - s);
export const ACT_NAMES = ['Acte1', 'Acte2', 'Acte3', 'Acte4', 'Acte5'] as const;

/** image (dans l'acte) correspondant à une seconde de la voix off */
export const v = (act: number, voiceSec: number) => sec(voiceSec) - ACT_START[act];

// petits utilitaires déterministes (pas de Math.random : rendu identique à chaque image)
export const rnd = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const easeOut = (t: number) => 1 - Math.pow(1 - clamp(t), 3);
export const prog = (f: number, a: number, b: number) => clamp((f - a) / (b - a));
