import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {ActAudio, Stage} from '../fx/Stage';
import {Flash, Letterbox, Shake, Sfx, SpeedLines, Word, useBass} from '../fx/Overlays';
import {Rig, Cam} from '../three/Rig';
import {Battlefield} from '../three/Decor';
import {Particles} from '../three/Nebula';
import {Post} from '../three/Post';
import {Sprite, Pose} from '../three/Sprite';
import {C, clamp, ease, easeOut, lerp, prog, rnd, sec} from '../timeline';

// ACTE 1 — L'UNIVERS & LE FLUX  (voix off 0:00 → 0:18)
const CENTER: [number, number, number] = [0, 0, -18];

const cam = (f: number): Cam => {
  if (f < 700) {
    const p = f / 700;
    return {
      pos: [lerp(-20, 6, p), lerp(9, 3.5, p) + Math.sin(f * 0.03) * 0.3, lerp(70, 14, p)],
      look: [0, 4 + Math.sin(f * 0.02), -20],
      fov: 52,
      roll: Math.sin(f * 0.02) * 0.02,
    };
  }
  const t = ease(prog(f, 700, 1080));
  const r = lerp(32, 12, t), a = lerp(0.19, 1.75, t);
  return {
    pos: [CENTER[0] + Math.sin(a) * r, lerp(3.5, 2.0, t), CENTER[2] + Math.cos(a) * r],
    look: [0, lerp(4, 3.4, t), CENTER[2]],
    fov: lerp(52, 30, ease(prog(f, 900, 1080))),
    roll: lerp(0, -0.06, t),
  };
};

const zeph = (f: number): Pose => {
  const t = f - sec(11.73);
  const pop = t < 0 ? 0 : easeOut(t / 14);
  const sy = t < 0 ? 0.001 : 1 + (1 - pop) * 0.7 + Math.sin(f * 0.05) * 0.012;
  const sx = t < 0 ? 0.001 : 1 - (1 - pop) * 0.35 + Math.sin(f * 0.05 + 1) * 0.01;
  return {pos: [0, 0, CENTER[2]], scale: 1, sx, sy, lean: Math.sin(f * 0.04) * 0.25, wind: 0.22};
};

const WARRIORS = Array.from({length: 18}, (_, i) => {
  const a = (i / 18) * Math.PI * 2 + 0.2;
  const r = 12 + rnd(i) * 5;
  return {i, x: Math.cos(a) * r, z: CENTER[2] + Math.sin(a) * r, at: sec(15.2) + i * 2};
});

export const Act1: React.FC = () => {
  const f = useCurrentFrame();
  const bass = useBass(0);
  const bg = f < sec(0.83) ? C.black : C.red;
  const spawn = f > sec(15.2) && f < sec(15.2) + 60;
  const elements: [string, number][] = [['FEU', 4.8], ['EAU', 5.82], ['TERRE', 6.69], ['VENT', 7.35], ['FOUDRE', 9.75], ['MÉTAL', 10.65]];
  const hitFrames = [...elements.map((e) => sec(e[1])), sec(11.73), sec(15.2)];
  const sinceHit = Math.min(...hitFrames.map((h) => (f >= h ? f - h : 999)));
  const impact = Math.max(0, 1 - sinceHit / 14);
  const shake = bass * 10 + impact * 26;

  return (
    <AbsoluteFill style={{background: bg}}>
      <ActAudio act={0} />
      <Sfx name="riser" at={0} volume={0.35} />
      <Sfx name="boom" at={sec(0.83)} />
      {elements.map(([, s], i) => <Sfx key={i} name="hit" at={sec(s)} volume={0.7} />)}
      <Sfx name="boom" at={sec(11.73)} volume={0.9} />
      <Sfx name="slash" at={sec(15.2)} />
      <Shake amp={shake}>
        <Stage bg={bg}>
          <Rig cam={cam} shake={0.08 * bass + impact * 0.25} />
          <Battlefield seed={3} />
          <Particles preset="embers" seed={11} area={[120, 4, 140]} center={[0, 0.5, -40]} />
          <Sprite src="zephyra" height={6.2} pose={zeph} eyeBoost={(ff) => (ff < sec(11.73) + 14 ? 0 : 8 + bass * 4)} outline={7} />
          {WARRIORS.map((w) => (
            <Sprite
              key={w.i}
              src={w.i % 2 ? 'bandit' : 'bandit2'}
              height={5.4}
              eyeBoost={(ff) => (ff < w.at + 4 ? 0 : 6)}
              outline={7}
              pose={(ff) => {
                const t = ff - w.at;
                if (t < 0) return {pos: [w.x, 0, w.z], sx: 0.001, sy: 0.001};
                const pop = easeOut(t / 10);
                const lunge = Math.max(0, Math.sin((ff + w.i * 9) * 0.07)) * 0.8;
                return {pos: [w.x * (1 - lunge * 0.04), 0, w.z * 1], sx: 1 - (1 - pop) * 0.3, sy: 1 + (1 - pop) * 0.6, lean: (w.x > 0 ? -1 : 1) * (0.5 + lunge), flip: w.x > 0, wind: 0.1};
              }}
            />
          ))}
          <Post bloom={1.6 + bass * 1.2} aberration={0.0016 * impact + 0.0006 * bass} />
        </Stage>
        <SpeedLines mode="horizontal" density={34} opacity={f < 700 ? 0.3 : 0} />
        <SpeedLines mode="radial" density={90} opacity={spawn ? 0.9 : impact * 0.5} />
        {elements.map(([t, s], i) => (
          <Word key={t} text={t} from={sec(s)} dur={30} size={t.length > 5 ? 300 : 400} x={960 + (i % 2 ? 260 : -260)} y={470 + (i % 3) * 70} rot={i % 2 ? 5 : -5} />
        ))}
        <Word text="THE FLUX" from={sec(3.3)} dur={60} size={260} rot={-3} y={560} />
        <Word text="×200" from={sec(15.2)} dur={70} size={340} rot={4} y={300} sub="GUERRIERS" />
      </Shake>
      <Flash at={sec(0.83)} dur={6} />
      <Flash at={sec(11.73)} dur={10} />
      <Flash at={sec(15.2)} dur={8} />
      <Letterbox h={64} />
    </AbsoluteFill>
  );
};
