import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {ActAudio, Stage} from '../fx/Stage';
import {BattleUI, Flash, Letterbox, Shake, Sfx, SpeedLines, Slash, Word, useBass} from '../fx/Overlays';
import {Rig, Cam} from '../three/Rig';
import {Post} from '../three/Post';
import {ArenaFight} from './ArenaFight';
import {C, lerp, rnd, v} from '../timeline';

// ACTE 4 — ACTION & GAMEPLAY  (voix off 0:39.75 → 0:47.48)
// Le fond change toutes les 30 images : Rouge / Bleu / Orange. Caméra : un plan différent à chaque cut.
const COLORS = [C.red, C.blue, C.orange];
export const SHOTS: ((t: number) => Cam)[] = [
  (t) => ({pos: [lerp(-16, -6, t), 3, 16], look: [0, 3, 0], fov: 48}),
  (t) => ({pos: [12, 14, lerp(14, 8, t)], look: [0, 1, 0], fov: 52, roll: 0.06}),
  (t) => ({pos: [lerp(8, 3, t), 1.2, 9], look: [0, 3.5, 0], fov: 36, roll: -0.05}),
  (t) => ({pos: [-14, 5, lerp(-2, 6, t)], look: [0, 3, 0], fov: 50}),
  (t) => ({pos: [lerp(2, -2, t), 22, 2], look: [0, 0, 0], fov: 55, roll: 0.15}),
  (t) => ({pos: [0, 2.5, lerp(24, 14, t)], look: [0, 4, -4], fov: 46}),
];
export const shotCam = (f: number, len = 30, offset = 0): Cam => {
  const i = Math.floor(f / len) + offset;
  const t = (f % len) / len;
  return SHOTS[((i % SHOTS.length) + SHOTS.length) % SHOTS.length](t);
};

export const Act4: React.FC = () => {
  const f = useCurrentFrame();
  const bass = useBass(3);
  const bg = COLORS[Math.floor(f / 30) % 3];
  const since = f % 30;
  const impact = Math.max(0, 1 - since / 10);
  const explosions = [0, 60, 120, 180, 240, 300, 360];
  return (
    <AbsoluteFill style={{background: bg}}>
      <ActAudio act={3} />
      <Sfx name="boom" at={0} volume={1} />
      {Array.from({length: 15}, (_, i) => <Sfx key={i} name={i % 2 ? 'hit' : 'whoosh'} at={i * 30} volume={0.55} />)}
      <Shake amp={bass * 12 + impact * 24}>
        <Stage bg={bg}>
          <Rig cam={(ff) => shotCam(ff)} shake={0.06 * bass + impact * 0.35} />
          <ArenaFight explosions={explosions} />
          <Post bloom={1.8 + bass * 1.5} aberration={0.003 * impact + 0.0006 * bass} />
        </Stage>
        <SpeedLines mode="radial" density={80} opacity={0.25 + impact * 0.6} />
        {[30, 90, 150, 210, 270, 330, 390, 450].map((s, i) => <Slash key={s} at={s} dur={7} angle={-30 + i * 14} thick={22} />)}
        <BattleUI from={0} turn={1 + Math.floor(f / 90)} cursor={Math.floor(f / 30) % 4} hp={[1 - f / 900, 0.9 - f / 560]} />
        <Word text="FAIS TES CHOIX" from={6} dur={52} size={180} rot={-3} y={330} />
        <Word text="TECHNIQUES" from={v(3, 41.3)} dur={48} size={230} rot={3} y={330} />
        <Word text="TOUR PAR TOUR" from={v(3, 45.1)} dur={56} size={210} rot={-3} y={330} />
        <Word text="DESTIN" from={v(3, 46.5)} dur={50} size={330} rot={4} y={420} />
      </Shake>
      {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330, 360, 390, 420, 450].map((a) => <Flash key={a} at={a} dur={3} />)}
      <Letterbox h={64} />
    </AbsoluteFill>
  );
};
