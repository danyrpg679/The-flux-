import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {ActAudio, Stage} from '../fx/Stage';
import {Flash, Letterbox, Shake, Sfx, SpeedLines, Slash, Word, useBass} from '../fx/Overlays';
import {Rig, Cam} from '../three/Rig';
import {Forest} from '../three/Decor';
import {Particles} from '../three/Nebula';
import {Post} from '../three/Post';
import {Sprite} from '../three/Sprite';
import {C, ease, easeOut, lerp, prog, v} from '../timeline';

// ACTE 3 — LA MENACE  (voix off 0:31.6 → 0:39.75)
// La musique COUPE NET à l'image 0 (volume 0 dans <ActAudio music=...>).
const T_EYES = v(2, 34.08); // « Des monstres rôdent »
const T_RENIES = v(2, 36.0); // « les Reniés »
const T_SLASH = v(2, 39.31); // « …équilibre du monde » : cut sec noir + slash

const FOES: {src: string; x: number; z: number; h: number; flip?: boolean}[] = [
  {src: 'bandit', x: -7, z: 4, h: 5.6}, {src: 'bandit2', x: 8, z: -1, h: 5.6, flip: true},
  {src: 'bandit', x: -3.5, z: -12, h: 5.4}, {src: 'bandit2', x: 4.5, z: -16, h: 5.4, flip: true},
  {src: 'bandit', x: 0, z: -24, h: 5.2},
];

const cam = (f: number): Cam => {
  if (f < T_EYES) return {pos: [0, 3.2, 28 - f * 0.05], look: [0, 4, -10], fov: 50, roll: Math.sin(f * 0.03) * 0.015};
  if (f < T_RENIES) {
    const t = f - T_EYES;
    const z = t < 40 ? lerp(16, 0.5, ease(t / 40)) : lerp(0.5, -0.5, (t - 40) / 100);
    const fov = t < 40 ? lerp(50, 24, ease(t / 40)) : lerp(24, 20, (t - 40) / 100);
    return {pos: [lerp(1.2, 0, easeOut(t / 40)), 6.2, z], look: [0, 6.6, -6], fov, roll: Math.sin(f * 0.6) * 0.012};
  }
  const t = f - T_RENIES;
  const a = lerp(-0.5, 0.6, t / (T_SLASH - T_RENIES));
  return {pos: [Math.sin(a) * 15, 1.6, Math.cos(a) * 15 + 2], look: [0, 4.2, -8], fov: 46, roll: lerp(0.08, -0.05, t / 200)};
};

export const Act3: React.FC = () => {
  const f = useCurrentFrame();
  const bass = useBass(2, () => 0); // musique coupée : plus de réactivité aux basses
  const cut = f >= T_SLASH;
  const bg = cut ? C.black : f >= T_EYES && f < T_RENIES ? C.black : C.orange;
  const impact = Math.max(0, 1 - Math.min(f - T_EYES >= 0 ? f - T_EYES : 99, f - T_RENIES >= 0 ? f - T_RENIES : 99, f - T_SLASH >= 0 ? f - T_SLASH : 99) / 14);
  return (
    <AbsoluteFill style={{background: bg}}>
      <ActAudio act={2} music={() => 0} />
      <Sfx name="hit" at={T_EYES} volume={1} />
      <Sfx name="whoosh" at={T_EYES - 2} />
      <Sfx name="hit" at={T_RENIES} volume={0.8} />
      <Sfx name="slash" at={T_SLASH} volume={1} />
      <Shake amp={impact * 22 + (f > T_EYES && f < T_RENIES ? 5 : 1.5)}>
        <Stage bg={bg}>
          <Rig cam={cam} shake={0.05 + impact * 0.3} />
          {!cut ? <Forest seed={5} count={60} /> : null}
          <Particles preset="leaves" seed={21} area={[60, 16, 60]} center={[0, 8, 0]} />
          <Sprite src="monstre" height={11} pose={() => ({pos: [0, 0, -7], wind: 0.04, sx: 1 + Math.sin(f * 0.09) * 0.012})} eyeBoost={(ff) => (ff < T_EYES ? 0 : 7)} />
          {FOES.map((fo, i) => (
            <Sprite
              key={i}
              src={fo.src}
              height={fo.h}
              outline={7}
              eyeBoost={(ff) => (ff < T_EYES + i * 6 ? 0 : 6 + (Math.sin(ff * 0.3 + i) > 0.85 ? -3 : 0))}
              pose={(ff) => ({pos: [fo.x, 0, fo.z], flip: fo.flip, lean: fo.flip ? -0.2 : 0.2, wind: 0.08, sy: 1 + Math.sin(ff * 0.05 + i) * 0.008})}
            />
          ))}
          <Post bloom={2.2} aberration={0.002 * impact} />
        </Stage>
        <SpeedLines mode="radial" density={70} opacity={f > T_EYES && f < T_EYES + 24 ? 1 : 0} />
        <Word text="RENIÉS" sub="LES TRAÎTRES" from={T_RENIES} dur={110} size={400} rot={-4} y={540} />
      </Shake>
      <Slash at={T_SLASH} dur={9} angle={-16} thick={34} />
      <Flash at={T_EYES} dur={5} />
      <Flash at={T_RENIES} dur={5} />
      <Letterbox h={64} />
    </AbsoluteFill>
  );
};
