import React from 'react';
import {Arena} from '../three/Decor';
import {Debris} from '../three/Debris';
import {Particles} from '../three/Nebula';
import {Sprite, Pose} from '../three/Sprite';
import {clamp, ease, lerp} from '../timeline';

/** Va-et-vient en dash (squash & stretch + inclinaison + traînée) entre deux points. */
export const dash = (f: number, a: [number, number], b: [number, number], period: number, phase = 0, y = 0): Pose => {
  const t = (((f + phase) % period) + period) % period / period;
  const out = t < 0.28 ? ease(t / 0.28) : t < 0.5 ? 1 : t < 0.78 ? 1 - ease((t - 0.5) / 0.28) : 0;
  const speed = t < 0.28 || (t >= 0.5 && t < 0.78) ? 1 : 0;
  const dirx = b[0] - a[0];
  return {
    pos: [lerp(a[0], b[0], out), y + (speed ? Math.sin(t * 40) * 0.05 : 0), lerp(a[1], b[1], out)],
    sx: speed ? 1.22 : 0.94 + (t > 0.28 && t < 0.4 ? 0.08 : 0),
    sy: speed ? 0.88 : 1.04,
    lean: (dirx > 0 ? 1 : -1) * (speed ? 2.2 : 0.2) * (t < 0.5 ? 1 : -1),
    flip: t >= 0.5 ? dirx > 0 : dirx < 0,
    rotZ: speed ? (dirx > 0 ? -0.1 : 0.1) * (t < 0.5 ? 1 : -1) : 0,
    wind: 0.2,
  };
};

export const ArenaFight: React.FC<{explosions: number[]; zephEyes?: (f: number) => number; calm?: boolean}> = ({explosions, zephEyes = () => 8, calm = false}) => (
  <>
    <Arena hidePillars={[0, 3, 7, 10]} />
    <Particles preset="sparks" seed={3} area={[26, 2, 26]} center={[0, 1, 0]} />
    <Particles preset="energy" seed={9} area={[22, 2, 22]} center={[0, 0.5, 0]} />
    <Sprite src="monstre" height={13} pose={() => ({pos: [0, 0, -20], wind: 0.03})} eyeBoost={() => 7} />
    <Sprite src="zephyra" height={5.8} pose={(f) => ({pos: [0, 0, -4], wind: 0.25, lean: Math.sin(f * 0.05) * 0.3, sy: 1 + Math.sin(f * 0.07) * 0.01})} eyeBoost={zephEyes} />
    {calm ? null : (
      <>
        <Sprite src="heros" height={5} trail={6} trailStep={2} pose={(f) => dash(f, [-9, 5], [4, 0], 60, 0)} />
        <Sprite src="bandit" height={5.2} trail={4} trailStep={2} pose={(f) => dash(f, [9, 4], [-3, 0], 60, 30)} />
        <Sprite src="heroine" height={5} trail={6} trailStep={2} pose={(f) => dash(f, [8, -6], [-2, 1], 90, 10)} />
        <Sprite src="kai" height={5} trail={5} trailStep={2} pose={(f) => dash(f, [-8, -7], [2, 2], 90, 55)} />
        <Sprite src="bandit2" height={5.2} trail={4} trailStep={2} pose={(f) => dash(f, [0, -12], [-5, 3], 120, 40)} />
      </>
    )}
    {explosions.map((e, i) => (
      <Debris key={e} start={e} origin={[((i * 7) % 11) - 5, 1, ((i * 5) % 9) - 3]} count={24} seed={i * 17 + 3} power={13} />
    ))}
  </>
);

export const clampShot = (f: number, len: number) => clamp(f / len);
