import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {ActAudio, Stage} from '../fx/Stage';
import {Flash, Letterbox, Shake, Sfx, SpeedLines, Word, useBass} from '../fx/Overlays';
import {Rig, Cam} from '../three/Rig';
import {PATH_STEP, PathRoofs, Rooftops, pathTop} from '../three/Decor';
import {Particles} from '../three/Nebula';
import {Post} from '../three/Post';
import {Sprite, Pose} from '../three/Sprite';
import {C, clamp, easeOut, lerp, prog, v} from '../timeline';

// ACTE 2 — SYLVÉRA & L'ACADÉMIE  (voix off 0:18 → 0:31.6) — fond bleu électrique
const Z0 = 10;
const SPEED = 0.17; // unités / image
const JUMP = PATH_STEP / SPEED; // images par saut (≈ 82)

/** Trajectoire de saut de toit en toit : position + squash/stretch + inclinaison. */
const runner = (f: number, lag: number, dx: number): Pose => {
  const ff = Math.max(0, f - lag);
  const q = (ff * SPEED) / PATH_STEP;
  const i = Math.floor(q), t = q - i;
  const y0 = pathTop(i), y1 = pathTop(i + 1);
  const air = clamp((t - 0.14) / 0.72);
  const y = t < 0.14 ? y0 : t > 0.86 ? y1 : lerp(y0, y1, air) + Math.sin(Math.PI * air) * 5.5;
  const land = t > 0.86 ? 1 - (t - 0.86) / 0.14 : 0;
  const crouch = t < 0.14 ? 1 - t / 0.14 : 0;
  const sy = 1 - 0.2 * Math.max(crouch, land) + (air > 0 && air < 1 ? 0.14 * Math.sin(Math.PI * air) : 0);
  return {
    pos: [dx, y, Z0 - ff * SPEED],
    sy, sx: 1 / sy,
    lean: air > 0 && air < 1 ? -1.6 : -0.5, // penché vers l'avant (vers la droite écran)
    rotZ: air > 0 && air < 1 ? -0.12 : 0,
    wind: 0.28,
  };
};
const heroAt = (f: number) => runner(f, 0, 0).pos;

const cam = (f: number): Cam => {
  const h = heroAt(f);
  const hz = h[2];
  if (f < 162) // plan bas latéral
    return {pos: [17, h[1] - 3, hz + 8 - f * 0.02], look: [0, h[1] + 1.5, hz - 4], fov: 46};
  if (f < 342) { // face aux héros, pousse vers eux
    const t = (f - 162) / 180;
    return {pos: [-3, h[1] + 1.5, hz - lerp(22, 12, t)], look: [0, h[1] + 3, hz], fov: lerp(55, 38, t), roll: lerp(0.05, 0, t)};
  }
  if (f < 618) { // orbite large
    const a = lerp(0.3, 1.5, (f - 342) / 276);
    return {pos: [Math.cos(a) * 24, h[1] + 5, hz + Math.sin(a) * 24 - 6], look: [0, h[1] + 2, hz - 6], fov: 48};
  }
  const t = (f - 618) / 198; // rangs : plan serré qui tourne
  return {pos: [12, h[1] + 3, hz + 12 - t * 6], look: [0, h[1] + 3, hz - 2], fov: lerp(44, 30, t), roll: Math.sin(f * 0.25) * 0.05};
};

const RANKS: [string, string][] = [['F', 'APPRENTI'], ['E', 'RECRUE'], ['D', 'ÉCLAIREUR'], ['C', 'GUERRIER'], ['B', 'VÉTÉRAN'], ['A', 'CHAMPION'], ['S', 'GRAND MAÎTRE']];
const rankStart = (i: number) => (i < 6 ? v(1, 28.3) + i * 18 : v(1, 30.15));

export const Act2: React.FC = () => {
  const f = useCurrentFrame();
  const bass = useBass(1);
  const beats = [v(1, 23.7), v(1, 24.5), v(1, 25.3), v(1, 26.1), v(1, 26.9)];
  const weaponNames = ['katana', 'kunai', 'shuriken', 'marteau', 'eventail'];
  const wi = beats.reduce((a, b, i) => (f >= b ? i : a), -1);
  const wSince = wi >= 0 ? f - beats[wi] : 999;
  const rankIdx = RANKS.reduce((a, _, i) => (f >= rankStart(i) ? i : a), -1);
  const impact = Math.max(0, 1 - Math.min(wSince, f - rankStart(Math.max(rankIdx, 0))) / 12);
  const shake = bass * 9 + (rankIdx >= 0 || wSince < 12 ? impact * 22 : 0);
  const wPose = (ff: number): Pose => {
    const t = Math.max(0, ff - beats[Math.max(wi, 0)]);
    const h = heroAt(ff);
    return {pos: [-1.5, h[1] + 4.2, h[2] - 2], scale: 1 + (1 - easeOut(t / 8)) * 0.8, rotZ: t * 0.35, wind: 0};
  };

  return (
    <AbsoluteFill style={{background: C.blue}}>
      <ActAudio act={1} />
      {[0, 162, 342, 618].map((a) => <Sfx key={a} name="whoosh" at={a} volume={0.6} />)}
      {beats.map((b) => <Sfx key={b} name="hit" at={b} volume={0.5} />)}
      {RANKS.map((_, i) => <Sfx key={i} name="hit" at={rankStart(i)} volume={0.55} />)}
      <Shake amp={shake}>
        <Stage bg={C.blue}>
          <Rig cam={cam} shake={0.05 * bass + impact * 0.2} />
          <Rooftops seed={4} count={46} length={165} />
          <PathRoofs z0={Z0} count={15} />
          <Particles preset="wind" seed={5} area={[50, 16, 50]} follow={(ff) => [0, heroAt(ff)[1] + 3, heroAt(ff)[2] - 25]} />
          <Particles preset="leaves" seed={8} area={[50, 14, 50]} follow={(ff) => [0, heroAt(ff)[1] + 7, heroAt(ff)[2] - 25]} />
          <Sprite src="heros" height={4.6} pose={(ff) => runner(ff, 0, 0)} trail={5} trailStep={3} eyeBoost={() => 6} />
          <Sprite src="heroine" height={4.6} pose={(ff) => runner(ff, 14, 1.8)} trail={4} trailStep={3} eyeBoost={() => 6} />
          <Sprite src="kai" height={4.6} pose={(ff) => runner(ff, 26, -1.8)} trail={4} trailStep={3} eyeBoost={() => 6} />
          {wi >= 0 && wSince < 26 ? <Sprite src={'w_' + weaponNames[wi]} eyes={false} height={3.4} pose={wPose} outline={5} /> : null}
          <Post bloom={1.5 + bass} aberration={0.0012 * impact + 0.0004 * bass} />
        </Stage>
        <SpeedLines mode="horizontal" density={46} opacity={0.35 + bass * 0.4} angle={-3} />
        <Word text="SYLVÉRA" from={0} dur={44} size={330} rot={-3} y={400} />
        <Word text="L'ACADÉMIE" from={v(1, 20.7)} dur={46} size={240} rot={3} y={420} />
        {RANKS.map(([l, n], i) => (
          <Word key={l} text={l} sub={n} from={rankStart(i)} dur={i < 6 ? 18 : 90} size={i < 6 ? 560 : 640} rot={i % 2 ? 4 : -4} x={i % 2 ? 640 : 1280} y={i < 6 ? 470 : 500} />
        ))}
      </Shake>
      {[0, 162, 342, 618].map((a) => <Flash key={a} at={a} dur={5} />)}
      {RANKS.map((_, i) => <Flash key={'r' + i} at={rankStart(i)} dur={4} />)}
      <Letterbox h={64} />
    </AbsoluteFill>
  );
};
