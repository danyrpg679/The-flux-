import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {ActAudio, Stage} from '../fx/Stage';
import {Flash, Letterbox, Shake, Sfx, SpeedLines, Slash, Word, useBass} from '../fx/Overlays';
import {Rig, Cam} from '../three/Rig';
import {Post} from '../three/Post';
import {ArenaFight} from './ArenaFight';
import {shotCam} from './Act4';
import {C, clamp, easeOut, lerp, rnd, v} from '../timeline';

// ACTE 5 — OUTRO  (voix off 0:47.48 → fin)
// Montage qui s'accélère (cuts de plus en plus courts, fonds qui s'enchaînent),
// coup final, flash blanc total sur la pause « Bienvenue dans… », puis le logo.
const T_FLASH = v(4, 53.55); // flash blanc total
const T_LOGO = v(4, 53.99); // « THE FLUX »
const T_CTA = v(4, 54.9); // « Disponible sur PC et mobile »
const T_FINAL = T_FLASH - 24; // coup final

// durées de plans qui raccourcissent : 48, 40, 34, 28, 22, 18, 14, 11, 9, 7…
const CUTS: number[] = (() => {
  const out = [0];
  let len = 48;
  while (out[out.length - 1] < T_FINAL) {
    out.push(out[out.length - 1] + Math.max(6, Math.round(len)));
    len *= 0.86;
  }
  return out;
})();
const COLS = [C.red, C.blue, C.orange, C.red, C.blue, C.orange, C.white];
const cutIndex = (f: number) => CUTS.reduce((a, c, i) => (f >= c ? i : a), 0);

const camAt = (f: number): Cam => {
  if (f >= T_FLASH) {
    const t = clamp((f - T_LOGO) / 360);
    return {pos: [lerp(-2, 2, t), 2.4, lerp(22, 15, t)], look: [0, 4, -4], fov: 40};
  }
  const i = cutIndex(f);
  return shotCam(f - CUTS[i], Math.max(6, (CUTS[i + 1] ?? T_FINAL) - CUTS[i]), i);
};

export const Act5: React.FC = () => {
  const f = useCurrentFrame();
  const bass = useBass(4);
  const idx = cutIndex(f);
  const bg = f >= T_FLASH ? C.black : f >= T_FINAL ? C.white : COLS[idx % COLS.length === 6 ? 0 : idx % 6];
  const since = f - CUTS[idx];
  const impact = f >= T_FLASH ? Math.max(0, 1 - (f - T_LOGO) / 20) : Math.max(0, 1 - since / 8);
  const logoT = f - T_LOGO;
  const logoScale = logoT < 0 ? 0 : 1 + 0.9 * Math.pow(1 - clamp(logoT / 9), 2);
  const logoGlow = 30 + 24 * bass + (logoT < 14 ? 80 : 0);
  const ctaT = f - T_CTA;
  return (
    <AbsoluteFill style={{background: bg}}>
      <ActAudio act={4} />
      <Sfx name="riser" at={0} volume={0.45} />
      {CUTS.map((c, i) => (c % 2 === 0 ? <Sfx key={c} name="whoosh" at={c} volume={0.4} /> : <Sfx key={c} name="hit" at={c} volume={0.4} />))}
      <Sfx name="slash" at={T_FINAL} />
      <Sfx name="boom" at={T_FLASH} volume={1} />
      <Shake amp={bass * 10 + impact * 26}>
        <Stage bg={bg}>
          <Rig cam={camAt} shake={0.05 * bass + impact * 0.3} />
          <ArenaFight
            explosions={[10, 70, 130, 190, 250, 310]}
            calm={f >= T_FLASH}
            zephEyes={(ff) => (ff < 20 ? 0 : 8 + bass * 5)}
          />
          <Post bloom={f >= T_FLASH ? 2.4 + bass * 1.5 : 1.8} aberration={0.003 * impact} />
        </Stage>
        <SpeedLines mode="radial" density={90} opacity={f >= T_FLASH ? 0.18 + bass * 0.5 : 0.3 + impact * 0.6} />
        {f < T_FLASH ? <Slash at={T_FINAL} dur={8} angle={-22} thick={44} /> : null}

        {/* LOGO */}
        {f >= T_LOGO ? (
          <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
            <div
              style={{
                fontFamily: 'Impact, "Arial Black", sans-serif', fontSize: 400, letterSpacing: 18, color: '#fff',
                WebkitTextStroke: '0px #000', transform: `scale(${logoScale}) rotate(-3deg)`, textAlign: 'center', lineHeight: 0.9,
                textShadow: `0 0 ${logoGlow}px rgba(255,255,255,.85), 12px 12px 0 #000`,
              }}
            >
              THE FLUX
            </div>
            {f >= T_CTA ? (
              <div
                style={{
                  position: 'absolute', bottom: 150, fontFamily: 'Impact, sans-serif', fontSize: 86, letterSpacing: 22, color: '#000',
                  background: '#fff', padding: '4px 46px', transform: `skewX(-14deg) translateX(${(1 - easeOut(ctaT / 10)) * 700}px)`,
                }}
              >
                SUR PC ET MOBILE
              </div>
            ) : null}
          </AbsoluteFill>
        ) : null}
      </Shake>
      {/* flash blanc total : tenu jusqu'au logo */}
      {f >= T_FLASH && f < T_LOGO ? <AbsoluteFill style={{background: '#fff'}} /> : null}
      <Flash at={T_LOGO} dur={10} />
      <Flash at={T_FINAL} dur={5} />
      <Letterbox h={64} />
    </AbsoluteFill>
  );
};
