import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {Act1} from './acts/Act1';
import {Act2} from './acts/Act2';
import {Act3} from './acts/Act3';
import {Act4} from './acts/Act4';
import {Act5} from './acts/Act5';
import {ACT_DUR, ACT_START} from './timeline';

export const ACT_COMPONENTS = [Act1, Act2, Act3, Act4, Act5];

/** Bande-annonce complète : les 5 actes mis bout à bout (3600 images). */
export const Trailer: React.FC = () => (
  <AbsoluteFill style={{background: '#000'}}>
    {ACT_COMPONENTS.map((A, i) => (
      <Sequence key={i} from={ACT_START[i]} durationInFrames={ACT_DUR[i]} name={`Acte ${i + 1}`}>
        <A />
      </Sequence>
    ))}
  </AbsoluteFill>
);
