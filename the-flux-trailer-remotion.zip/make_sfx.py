# Génère des effets sonores synthétiques (lame, impact, whoosh, riser) -> public/audio/sfx_*.wav
import numpy as np, wave
SR=44100
def save(name,x):
    x=x/np.max(np.abs(x))*0.9
    with wave.open('public/audio/sfx_%s.wav'%name,'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((x*32767).astype('<i2').tobytes())
rng=np.random.default_rng(7)
def t(d): return np.linspace(0,d,int(SR*d),endpoint=False)
def lp(x,a):  # simple one-pole low-pass
    y=np.zeros_like(x);s=0
    for i,v in enumerate(x): s+=a*(v-s);y[i]=s
    return y
# slash : bruit filtré, brillant, balayage rapide
d=0.55;tt=t(d);n=rng.standard_normal(tt.size)
hp=n-lp(n,0.05);env=np.exp(-tt*7)*(1-np.exp(-tt*200))
ring=np.sin(2*np.pi*(3200-2000*tt)*tt)*np.exp(-tt*9)*0.4
save('slash',(hp*env+ring))
# impact : thump grave + claque
d=0.9;tt=t(d);f=90*np.exp(-tt*6)+35
th=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*5)
cl=lp(rng.standard_normal(tt.size),0.4)*np.exp(-tt*30)
save('hit',th*1.2+cl*0.7)
# boom (flash final)
d=2.2;tt=t(d);f=60*np.exp(-tt*2)+28
bo=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-tt*1.6)
nz=lp(rng.standard_normal(tt.size),0.15)*np.exp(-tt*4)
save('boom',bo+nz*0.6)
# whoosh court
d=0.5;tt=t(d);n=lp(rng.standard_normal(tt.size),0.08)
save('whoosh',n*np.sin(np.pi*tt/d)**2)
# riser (montée)
d=5.0;tt=t(d);n=rng.standard_normal(tt.size);base=lp(n,0.03)
sw=np.sin(2*np.pi*np.cumsum(200+1800*(tt/d)**2)/SR)*0.3
save('riser',(base*3+sw)*(tt/d)**2)
print('ok')
